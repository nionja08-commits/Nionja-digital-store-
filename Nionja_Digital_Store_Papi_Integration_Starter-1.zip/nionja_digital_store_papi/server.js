require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const API_KEY = process.env.PAPI_API_KEY || '';
const WEBHOOK_SECRET = process.env.PAPI_WEBHOOK_SECRET || '';
const PRODUCTS = require('./products.json');
const DATA_DIR = path.join(__dirname, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '{}');

function readOrders() { try { return JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8')); } catch { return {}; } }
function writeOrders(orders) { fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2)); }
function safeEqualHex(a, b) {
  try { const aa = Buffer.from(a, 'hex'); const bb = Buffer.from(b, 'hex'); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); }
  catch { return false; }
}
function verifyPapiSignature(rawBody, header) {
  if (!Buffer.isBuffer(rawBody) || !header || !WEBHOOK_SECRET) return false;
  const parts = {};
  for (const item of header.split(',')) { const [key, ...rest] = item.trim().split('='); parts[key] = rest.join('='); }
  const { t, v1 } = parts;
  if (!/^\d+$/.test(t || '') || !/^[0-9a-f]{64}$/.test(v1 || '')) return false;
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(t)) > 300) return false;
  const expected = crypto.createHmac('sha256', WEBHOOK_SECRET).update(`${t}.`).update(rawBody).digest('hex');
  return safeEqualHex(expected, v1);
}

// Papi callback must receive the original raw body before JSON parsing.
app.post('/api/papi/notify', express.raw({ type: 'application/json' }), (req, res) => {
  if (!verifyPapiSignature(req.body, req.get('X-Papi-Signature'))) return res.status(401).send('Invalid signature');
  let n;
  try { n = JSON.parse(req.body.toString('utf8')); } catch { return res.status(400).send('Invalid JSON'); }
  const ref = n.merchantPaymentReference;
  const orders = readOrders();
  const order = orders[ref];
  if (!order || !n.notificationToken || n.notificationToken !== order.notificationToken) return res.status(400).send('Unknown order/token');
  if (Number(n.amount) !== Number(order.amount)) return res.status(400).send('Amount mismatch');
  if (n.paymentStatus === 'SUCCESS') order.status = 'PAID';
  else if (['FAILED', 'CANCELLED', 'EXPIRED'].includes(n.paymentStatus)) order.status = n.paymentStatus;
  order.lastNotificationAt = new Date().toISOString();
  order.paymentMethod = n.paymentMethod || order.paymentMethod || null;
  orders[ref] = order; writeOrders(orders);
  return res.status(200).json({ ok: true });
});

app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Nionja Digital Store Papi backend' }));

app.post('/api/create-payment', async (req, res) => {
  if (!API_KEY || !WEBHOOK_SECRET || !BASE_URL.startsWith('https://')) {
    return res.status(503).json({ error: 'Le backend doit être configuré avec les clés Papi et une URL publique HTTPS.' });
  }
  const product = PRODUCTS.find(p => p.id === Number(req.body.productId));
  const clientName = String(req.body.clientName || '').trim().slice(0, 100);
  const payerEmail = String(req.body.payerEmail || '').trim().slice(0, 150);
  const payerPhone = String(req.body.payerPhone || '').trim().slice(0, 30);
  const provider = String(req.body.provider || '').toUpperCase();
  if (!product) return res.status(400).json({ error: 'Produit non configuré côté serveur.' });
  if (!clientName) return res.status(400).json({ error: 'Veuillez saisir votre nom.' });
  if (!['ORANGE_MONEY', 'AIRTEL_MONEY'].includes(provider)) return res.status(400).json({ error: 'Choisissez Orange Money ou Airtel Money.' });
  if (payerPhone.length < 8) return res.status(400).json({ error: 'Veuillez saisir un numéro Mobile Money valide.' });
  const reference = 'NDS-' + crypto.randomUUID();
  const body = {
    amount: product.price,
    currency: 'MGA',
    displayCurrency: 'MGA',
    reference,
    clientName,
    description: `Nionja Digital Store - ${product.title}`.slice(0, 255),
    provider,
    payerPhone,
    ...(payerEmail ? { payerEmail } : {}),
    successUrl: `${BASE_URL}/?payment=return&ref=${encodeURIComponent(reference)}`,
    failureUrl: `${BASE_URL}/?payment=failed&ref=${encodeURIComponent(reference)}`,
    notificationUrl: `${BASE_URL}/api/papi/notify`,
    validDuration: 60
  };
  try {
    const papiResponse = await fetch('https://app.papi.mg/engine/api/payment-links', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Token': API_KEY },
      body: JSON.stringify(body)
    });
    const result = await papiResponse.json();
    if (!papiResponse.ok || !result.data?.paymentLink) {
      return res.status(502).json({ error: result?.error?.message || 'Papi n’a pas pu créer le lien de paiement.' });
    }
    const orders = readOrders();
    orders[reference] = {
      reference, productId: product.id, title: product.title, amount: product.price,
      status: 'PENDING', paymentLink: result.data.paymentLink,
      notificationToken: result.data.notificationToken, createdAt: new Date().toISOString(),
      file: product.file, clientName, payerEmail, payerPhone, provider
    };
    writeOrders(orders);
    return res.json({ paymentLink: result.data.paymentLink, reference });
  } catch (e) {
    return res.status(502).json({ error: 'Connexion à Papi impossible. Réessayez plus tard.' });
  }
});

app.get('/api/order/:reference', (req, res) => {
  const order = readOrders()[req.params.reference];
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  res.json({ reference: order.reference, title: order.title, amount: order.amount, status: order.status,
    downloadUrl: order.status === 'PAID' ? `/api/download/${encodeURIComponent(order.reference)}` : null });
});

app.get('/api/download/:reference', (req, res) => {
  const order = readOrders()[req.params.reference];
  if (!order || order.status !== 'PAID') return res.status(403).send('Le téléchargement est disponible uniquement après confirmation du paiement.');
  const filePath = path.resolve(__dirname, 'private-products', order.file || '');
  const privateDir = path.resolve(__dirname, 'private-products') + path.sep;
  if (!filePath.startsWith(privateDir) || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    return res.status(404).send('Fichier numérique non ajouté par le vendeur. Contactez la boutique.');
  }
  res.download(filePath);
});

app.get('/payment-status.html', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'payment-status.html')));
app.listen(PORT, () => console.log(`Nionja Digital Store backend listening on ${PORT}`));
